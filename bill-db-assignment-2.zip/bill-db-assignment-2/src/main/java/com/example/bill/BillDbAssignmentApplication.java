package com.example.bill;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BillDbAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(BillDbAssignmentApplication.class, args);
	}

}
